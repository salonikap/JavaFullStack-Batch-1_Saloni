package com.verizon.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;

	public String addCustomer(Customer customer) {

		//
		customerDao.save(customer);
		return "Added";
	}

	public List<Customer> getCustomers() {
		//
		List<Customer> customerList = new ArrayList<>();
		customerList = customerDao.findAll();
		return customerList;
	}

	public Customer updateCustomer(String email, Customer customer) {
		//
		Optional<Customer> optionalCustomer = customerDao.findByEmail(email);
		if (optionalCustomer.isPresent()) {
			Customer existingCustomer = optionalCustomer.get();
			existingCustomer.setEmail(customer.getEmail());
		}
		return new Customer();
	}

	public Customer deleteCustomer(Integer cid) {
		//
		if(customerDao.existsById(cid))
		{
		customerDao.deleteById(cid);
		return new Customer();
		}
		return null;
	}
}
